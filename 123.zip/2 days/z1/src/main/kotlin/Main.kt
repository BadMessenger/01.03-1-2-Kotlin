import sun.security.ec.point.ProjectivePoint.Mutable


fun main(args: Array<String>) {

    println("Введите время в секундах: ")
    val time: Int = readLine()?.toInt()?: 0
    val minute = time / 60
    val days = time / 3600
    val str = time.toLong()
    val a = minute.toString()
    val spl = a.toCharArray().map {
        it.toString().toInt()
    }
    val q = spl.last()
    val w = q.toInt()

    val a1 = days.toString()
    val spl1 = a.toCharArray().map {
        it.toString().toInt()
    }
    val q1 = spl1.last()
    val w1 = q1.toInt()


    when (time){
        in 0..60 -> println("был(а) в сети только что")
        in 61..60*60 -> if (3600%time==1){println("был(а) в сети ${minute} минуту назад")}
        else if (w==2||w==3||w==4){println("был(а) в сети ${minute} минуты назад")}
        else{println("был(а) в сети ${minute} минут назад")}

        in 60*60+1..24*60*60 -> if (3600*24%time==1){println("был(а) в сети ${time} час назад")}
        else if (w1==2||w1==3||w1==4){println("был(а) в сети ${minute} часа назад")}
        else{println("был(а) в сети ${minute} часов назад")}

        in 24*60*60+1..2*24*60*60 -> println("был(а) вчера")
        in 2*24*60*60+1..3*24*60*60 -> println("был(а) позавчера")
        else -> println("был(а) давно")
    }


}